import * as THREE from 'three';
import { Block, BlockRegistry } from '@/lib/three';

export type InstancingResult = {
  group: THREE.Group;
  meshes: Partial<Record<Block, THREE.InstancedMesh>>;
};

export function countBlocks(grid: Uint8Array, CHUNK: number) {
  const counts: Record<Block, number> = {
    [Block.Air]: 0,
    [Block.Grass]: 0,
    [Block.Gizmos]: 0,
  };

  const totalBlocks = CHUNK * CHUNK * CHUNK; // Guarda el total de bloques para agregar. (chunk = 8 -> 512 bloques)
  
  for (let i = 0; i < totalBlocks; i++) {
    const block = grid[i] as Block;
    
    counts[block]++;
  }
  
  return counts;
}

/**
 * Construye InstancedMesh por tipo de bloque y setea matrices por posición.
 * Deja el grupo centrado respecto al origen (offset 0.5 para centrar cubos).
 */
export function buildInstancedChunk(
  grid: Uint8Array,
  CHUNK: number,
  cubeGeo: THREE.BufferGeometry,
  registry: BlockRegistry
): InstancingResult {

  const group = new THREE.Group();
  const counts = countBlocks(grid, CHUNK);
  
  const makeMesh = (block: Block) => {
    const meshMaterial = registry.materialOf(block);

    const mesh = new THREE.InstancedMesh(cubeGeo, meshMaterial, Math.max(1, counts[block]));
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    return mesh;
  };

  const grassMesh = makeMesh(Block.Grass);
  const gizmosMesh = makeMesh(Block.Gizmos);
  group.add(grassMesh);
  group.add(gizmosMesh);

  const tempMatrix = new THREE.Matrix4();
  const tempPosition = new THREE.Vector3();

  const cursor: Record<Block, number> = {
    [Block.Air]: 0, [Block.Grass]: 0, [Block.Gizmos]: 0,
  };

  const GRID_HALF = CHUNK / 2;
  const offset = new THREE.Vector3(-GRID_HALF + 0.5, -GRID_HALF + 0.5, -GRID_HALF + 0.5);


  for (let z = 0; z < CHUNK; z++) {
    for (let y = 0; y < CHUNK; y++) {
      for (let x = 0; x < CHUNK; x++) {
        const i = x + y * CHUNK + z * CHUNK * CHUNK;
        const b = grid[i] as Block;
        if (b === Block.Air) continue;
        tempPosition.set(x, y, z).add(offset);
        tempMatrix.makeTranslation(tempPosition.x, tempPosition.y, tempPosition.z);
        switch (b) {
          case Block.Grass:  grassMesh.setMatrixAt(cursor[b]++, tempMatrix); break;
          case Block.Gizmos: gizmosMesh.setMatrixAt(cursor[b]++, tempMatrix); break;
        }
      }
    }
  }
  grassMesh.instanceMatrix.needsUpdate = true;
  gizmosMesh.instanceMatrix.needsUpdate = true;

  return {
    group,
    meshes: { [Block.Grass]: grassMesh }
  };
}