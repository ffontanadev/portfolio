import * as THREE from 'three';

/**
 * Encapsula el cálculo de cámara + renderer para encuadrar el cubo instanciado.
 */
export function fitRendererAndCamera( 
  container: HTMLElement,
  renderer: THREE.WebGLRenderer,
  camera: THREE.PerspectiveCamera,
  lookAt: THREE.Vector3,
  CHUNK: number
) {
  const { width, height } = container.getBoundingClientRect();
  renderer.setSize(width, height, false);
  const fov = camera.fov * (Math.PI / 180);
  const cubeSize = CHUNK;
  const dist = (cubeSize * 0.54) / Math.tan(fov / 2); 
  
  camera.aspect = width / height;
  camera.position.set(0, CHUNK/2, dist * 2);
  camera.lookAt(lookAt);
  camera.updateProjectionMatrix();
}
