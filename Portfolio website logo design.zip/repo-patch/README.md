# 2a "Tight FF." — repo patch

Four code edits + a regenerated icon set. Everything under `repo-patch/public/` drops straight into `portfolio-main/public/` (same filenames, so `index.html` and `site.webmanifest` need no changes).

## 1. `src/index.css` — add two utilities

Put these next to the existing `.font-display-*` block (Type micro-tuning section):

```css
/* Logo mark (2a). Fraunces 800 at display opsz with WONK serifs, tracked to
   -0.09em so the two F's nest; the period keeps the light italic and carries
   the only coral in the mark. */
.logo-mark {
  font-family: var(--font-display);
  font-weight: 800;
  letter-spacing: -0.09em;
  font-variation-settings: "opsz" 144, "SOFT" 60, "WONK" 1;
}
.logo-mark .logo-dot {
  font-weight: 300;
  font-style: italic;
  letter-spacing: 0;
  font-variation-settings: "opsz" 144, "SOFT" 100;
}
```

## 2. `src/components/Navigation.tsx` — the logo

Replace the two `<span>`s inside the logo `<motion.a>` (and drop `items-baseline gap-1`, the tracking now does that work):

```tsx
<motion.a
    href={home}
    className="group flex select-none"
    whileHover={{ scale: 1.02 }}
    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
>
    <span className="logo-mark text-2xl group-hover:text-coral-700 transition-colors duration-500">
        FF<span className="logo-dot text-coral-700/80">.</span>
    </span>
</motion.a>
```

## 3. `src/components/Footer.tsx` — the large lockup

```tsx
<div className="flex mb-4">
    <span className="logo-mark text-3xl md:text-5xl">
        FF<span className="logo-dot text-coral-700">.</span>
    </span>
</div>
```

## 4. `scripts/og-template.html` — match the mark

```css
.wordmark {
  font-size: 44px;
  font-weight: 800;
  letter-spacing: -0.09em;
  font-variation-settings: "opsz" 144, "SOFT" 60, "WONK" 1;
}
.wordmark .dot {
  color: var(--coral-500);
  font-style: italic;
  font-weight: 300;
  letter-spacing: 0;
  font-variation-settings: "opsz" 144, "SOFT" 100;
}
```

Then `pnpm og` to regenerate `public/og-image.jpg`.

## 5. Icons

The mark reduces to `F.` below ~32px — two F's at that size turn to mud. All files were rendered from the same 512px master, cream `#FFF8F3` ground, ink `#1A1A1A` F, coral `#B8433A` period:

| file | size | notes |
| --- | --- | --- |
| `favicon.svg` | 128 | embedded PNG, same pattern as the file it replaces |
| `favicon.ico` | 32 | single-image ICO |
| `favicon-96x96.png` | 96 | |
| `apple-touch-icon.png` | 180 | |
| `web-app-manifest-192x192.png` | 192 | |
| `web-app-manifest-512x512.png` | 512 | |

Delete `repo-patch/public/_src-light-512.png` — it is only the render master.

Two things I did not change, say the word and I will:
- `<meta name="theme-color" content="#000000">` in `index.html` — `#FFF8F3` would match the icon ground.
- `favicon.svg` still ships a raster inside the SVG (as today). A true vector favicon needs the Fraunces `F` converted to outlines, which is a font-editor step.
